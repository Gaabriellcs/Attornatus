package com.Attor.Attor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AttorApplicationTests {

	@Test
	void contextLoads() {
	}

}
