package com.Attor.Attor.pessoa;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizarPessoa(
		
		@NotNull
		Long id, 
		String nome, 
		String nascimento,
		Endereco endereco) {

	

}
