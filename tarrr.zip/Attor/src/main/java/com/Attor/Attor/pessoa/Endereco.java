package com.Attor.Attor.pessoa;

import jakarta.persistence.Embeddable;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Embeddable
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Endereco {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String logradouro;
	private String cep;
	private String numero;

	
	public Endereco(DadosEndereco endereco) {
		this.logradouro = endereco.logradouro();
		this.cep = endereco.cep();
		this.numero = endereco.numero();
	}

	

	}

