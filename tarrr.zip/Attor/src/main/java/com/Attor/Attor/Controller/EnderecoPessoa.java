package com.Attor.Attor.Controller;

import com.Attor.Attor.pessoa.Endereco;
import com.Attor.Attor.pessoa.Pessoa;


public record EnderecoPessoa(String nome, Endereco endereco) {
	
	public EnderecoPessoa(Pessoa pessoa) {
	this(pessoa.getNome(), pessoa.getEndereco());
	}
}
