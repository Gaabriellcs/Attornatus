package com.Attor.Attor.pessoa;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizarEndereco(
		
		
		@NotNull
		Long id, 
		Endereco endereco) {

}
