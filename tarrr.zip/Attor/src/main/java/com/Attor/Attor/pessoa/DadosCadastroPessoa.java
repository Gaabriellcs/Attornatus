package com.Attor.Attor.pessoa;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;

public record DadosCadastroPessoa (
		
		@NotBlank
		String nome,
		@NotBlank
		String nascimento,
		@NotBlank @Valid
		DadosEndereco endereco){


	
}
