package com.Attor.Attor.Controller
;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Attor.Attor.pessoa.DadosCadastroPessoa;
import com.Attor.Attor.pessoa.Pessoa;
import com.Attor.Attor.pessoa.PessoaRepository;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/Usuarios")
public class PessoaController {
	
	@Autowired
	private PessoaRepository repository;
	
	
	@PostMapping
	@Transactional
	public void cadastrar(@RequestBody @Valid DadosCadastroPessoa dados) {
		
		repository.save(new Pessoa(dados));
	}

	
	@GetMapping
	@RequestMapping("/listar")
	public List <Pessoa> listar1(){
		return repository.findAll();
		
	}
	
	@GetMapping
	@RequestMapping("/Enderecos")
	public List<EnderecoPessoa> listarEndereco1(){
		return repository.findAll().stream().map(EnderecoPessoa::new).toList();
		
	}
	

}
