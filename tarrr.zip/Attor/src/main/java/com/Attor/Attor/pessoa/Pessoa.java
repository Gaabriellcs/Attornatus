package com.Attor.Attor.pessoa;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "pessoa")
@Entity(name = "Pessoa")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class Pessoa {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nome;
	private String nascimento;
	
	
	@Embedded
	Endereco endereco;


	public Pessoa (DadosCadastroPessoa dados) {
	
	this.nome = dados.nome();
	this.nascimento = dados.nascimento();
	this.endereco = new Endereco(dados.endereco());
	
}


	public void atualizarInformaoces(DadosAtualizarPessoa dados) {
		if(dados.nome() != null) {
		this.nome = dados.nome();
		}
		if(dados.nascimento() != null) {
			this.nascimento = dados.nascimento();
			}
	}


	


	
		
	} 



