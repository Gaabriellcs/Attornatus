create table pessoa(

id bigint not null auto_increment,
nome varchar(100) not null,
nascimento varchar (100) not null,
logradouro varchar (100) not null,
cep varchar (9) not null,
numero varchar (20),

primary key (id)

); 